/*
 * SPDX-FileCopyrightText: 2025 Espressif Systems (Shanghai) CO., LTD
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef _CONSOLE_MODULE_H_
#define _CONSOLE_MODULE_H_

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */

/**
 * @brief
 *
 * @return
 */
void app_console();

#ifdef __cplusplus
}
#endif  /* __cplusplus */
#endif  /* _CONSOLE_MODULE_H_ */
