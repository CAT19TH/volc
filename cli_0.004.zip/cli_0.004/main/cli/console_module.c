/*  Console example.

   This example code is in the Public Domain (or CC0 licensed, at your option.)

   Unless required by applicable law or agreed to in writing, this
   software is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
   CONDITIONS OF ANY KIND, either express or implied.
*/

#include <string.h>
#include <ctype.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_wifi.h"
#include "nvs_flash.h"
#include "esp_log.h"
#include "audio_mem.h"

// #include "esp_audio.h"
// #include "esp_peripherals.h"
// #include "periph_wifi.h"
#include "periph_console.h"
#include "wifi_service.h"
#if CONFIG_SOC_BT_SUPPORTED && CONFIG_BT_ENABLED
#include "esp_bt.h"
#include "esp_bt_main.h"
#include "esp_gap_bt_api.h"
#include "blufi_config.h"
#include "ble_gatts_module.h"
#endif  /* CONFIG_SOC_BT_SUPPORTED && CONFIG_BT_ENABLED */

#include "audio_sys.h"

#include "audio_idf_version.h"
#include "esp_bt_device.h"

#if (ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 1, 0))
#include "esp_netif.h"
#else
#include "tcpip_adapter.h"
#endif

#define SAMPLE_DEVICE_NAME "ESP_ADF_COEX_EXAMPLE"

// #define  ESP_AUDIO_AUTO_PLAY

static const char                *TAG = "CONSOLE_EXAMPLE";
// static esp_audio_handle_t         player;
static esp_periph_set_handle_t    set;
// static playlist_operator_handle_t playlist;
// static xTimerHandle               tone_stop_tm_handle;
// static int                        auto_play_type;
// static audio_element_handle_t     mp3_el;
static esp_wifi_setting_handle_t  wifi_setting_handle = NULL;
static periph_service_handle_t    wifi_serv           = NULL;

static bool g_wifi_connect_state = false;

static esp_err_t blufi_start(esp_periph_handle_t periph, int argc, char *argv[])
{
#if CONFIG_SOC_BT_SUPPORTED && CONFIG_BT_ENABLED
    ble_gatts_module_start_adv();
    blufi_set_sta_connected_flag(wifi_setting_handle, false);
    wifi_service_setting_start(wifi_serv, 0);
#else
    ESP_LOGW(TAG, "Not support blufi now");
#endif
    return ESP_OK;
}

static esp_err_t wifi_set(esp_periph_handle_t periph, int argc, char *argv[])
{
    wifi_config_t w_config = {0};
    switch (argc) {
        case 2:
            memcpy(w_config.sta.password, argv[1], sizeof(w_config.sta.password));
            FALL_THROUGH;
        case 1:
            memcpy(w_config.sta.ssid, argv[0], sizeof(w_config.sta.ssid));
            ESP_LOGI(TAG, "Connecting Wi-Fi, SSID:\"%s\" PASSWORD:\"%s\"", w_config.sta.ssid, w_config.sta.password);
            wifi_service_set_sta_info(wifi_serv, &w_config);
            wifi_service_disconnect(wifi_serv);
            wifi_service_connect(wifi_serv);
            break;
        default:
            ESP_LOGE(TAG, "Invalid SSID or PASSWORD");
            return ESP_ERR_INVALID_ARG;
    }
    return ESP_OK;
}

static esp_err_t wifi_info(esp_periph_handle_t periph, int argc, char *argv[])
{
    wifi_config_t w_config = {0};
    wifi_ap_record_t ap_info = {0};
    esp_err_t ret  = esp_wifi_sta_get_ap_info(&ap_info);
    if (ret == ESP_ERR_WIFI_NOT_CONNECT) {
        ESP_LOGI(TAG, "Not connected Wi-Fi");
        return ESP_OK;
    }
    if (ESP_OK == esp_wifi_get_config(WIFI_IF_STA, &w_config)) {
        ESP_LOGI(TAG, "Connected Wi-Fi, SSID:\"%s\"", w_config.sta.ssid);
    } else {
        ESP_LOGE(TAG, "esp_wifi_get_config failed");
        return ESP_FAIL;
    }
    return ESP_OK;
}

static esp_err_t sys_reset(esp_periph_handle_t periph, int argc, char *argv[])
{
    esp_restart();
    return ESP_OK;
}

static esp_err_t show_free_mem(esp_periph_handle_t periph, int argc, char *argv[])
{
    AUDIO_MEM_SHOW(TAG);
    return ESP_OK;
}


#ifdef CONFIG_FREERTOS_GENERATE_RUN_TIME_STATS
static esp_err_t run_time_stats(esp_periph_handle_t periph, int argc, char *argv[])
{
    static char buf[1024];
    vTaskGetRunTimeStats(buf);
    printf("Run Time Stats:\nTask Name    Time    Percent\n%s\n", buf);
    return ESP_OK;
}
#endif

#ifdef CONFIG_FREERTOS_USE_TRACE_FACILITY
static esp_err_t task_list(esp_periph_handle_t periph, int argc, char *argv[])
{
    static char buf[1024];
    vTaskList(buf);
    printf("Task List:\nTask Name    Status   Prio    HWM    Task Number\n%s\n", buf);
    return ESP_OK;
}
#endif

static esp_err_t task_real_time_states(esp_periph_handle_t periph, int argc, char *argv[])
{
    audio_sys_get_real_time_stats();
    return ESP_OK;
}

const periph_console_cmd_t cli_cmd[] = {
    /* ======================== Wi-Fi ======================== */
    {.cmd = "join", .id = 20, .help = "Join Wi-Fi AP as a station", .func = wifi_set},
    {.cmd = "wifi", .id = 21, .help = "Get connected AP information", .func = wifi_info},
    {.cmd = "blufi", .id = 22, .help = "Config Wi-Fi using BLE", .func = blufi_start},

    /* ======================== System ======================== */
    {.cmd = "reboot", .id = 30, .help = "Reboot system", .func = sys_reset},
    {.cmd = "free", .id = 31, .help = "Get system free memory", .func = show_free_mem},
#ifdef CONFIG_FREERTOS_GENERATE_RUN_TIME_STATS
    {.cmd = "stat", .id = 32, .help = "Show processor time of all FreeRTOS tasks", .func = run_time_stats},
#endif  /* CONFIG_FREERTOS_GENERATE_RUN_TIME_STATS */
#ifdef CONFIG_FREERTOS_USE_TRACE_FACILITY
    {.cmd = "tasks", .id = 33, .help = "Get information about running tasks", .func = task_list},
#endif  /* CONFIG_FREERTOS_USE_TRACE_FACILITY */
    {.cmd = "system", .id = 34, .help = "Get freertos all task states information", .func = task_real_time_states},
};


static esp_err_t wifi_service_cb(periph_service_handle_t handle, periph_service_event_t *evt, void *ctx)
{
    ESP_LOGD(TAG, "Event type:%d,source:%p, data:%p,len:%d,ctx:%p",
             evt->type, evt->source, evt->data, evt->len, ctx);
    if (evt->type == WIFI_SERV_EVENT_CONNECTED) {
        g_wifi_connect_state = true;
        esp_err_t set_dev_name_ret = esp_bt_dev_set_device_name(SAMPLE_DEVICE_NAME);
        if (set_dev_name_ret) {
            ESP_LOGE(TAG, "Set BT device name failed, error code = %x, line(%d)", set_dev_name_ret, __LINE__);
        }
        ESP_LOGI(TAG, "WIFI_CONNECTED");
    } else if (evt->type == WIFI_SERV_EVENT_DISCONNECTED) {
        g_wifi_connect_state = false;
        ESP_LOGI(TAG, "WIFI_DISCONNECTED");
    } else if (evt->type == WIFI_SERV_EVENT_SETTING_TIMEOUT) {
        ESP_LOGI(TAG, "WIFI_SETTING_TIMEOUT");
    }
    return ESP_OK;
}

static void cli_setup_ble(void)
{
#if CONFIG_SOC_BT_SUPPORTED && CONFIG_BT_ENABLED
#if CONFIG_IDF_TARGET_ESP32
    ESP_ERROR_CHECK(esp_bt_controller_mem_release(ESP_BT_MODE_CLASSIC_BT));
#endif
    esp_bt_controller_config_t bt_cfg = BT_CONTROLLER_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_bt_controller_init(&bt_cfg));
    ESP_ERROR_CHECK(esp_bt_controller_enable(ESP_BT_MODE_BLE));
    esp_bluedroid_init();
    esp_bluedroid_enable();
    ble_gatts_module_init();
    esp_err_t set_dev_name_ret = esp_bt_dev_set_device_name(SAMPLE_DEVICE_NAME);
    if (set_dev_name_ret) {
        ESP_LOGE(TAG, "Set BT device name failed, error code = %x, line(%d)", set_dev_name_ret, __LINE__);
    }
    ESP_LOGI(TAG, "[4.3] Create Bluetooth peripheral");
    wifi_setting_handle = blufi_config_create(NULL);
#endif
}

static void cli_setup_wifi(void)
{
    wifi_config_t sta_cfg = {
        .sta = {
            .ssid = "ssid",
            .password = "password",
            .threshold.authmode = WIFI_AUTH_WPA2_PSK,
        },
    };

    wifi_service_config_t cfg = WIFI_SERVICE_DEFAULT_CONFIG();
    cfg.task_stack = 6 * 1024;
    cfg.extern_stack = true;
    cfg.evt_cb = wifi_service_cb;
    cfg.cb_ctx = NULL;
    cfg.setting_timeout_s = 60;
    wifi_serv = wifi_service_create(&cfg);

    int reg_idx = 0;
    esp_wifi_setting_register_notify_handle(wifi_setting_handle, (void *)wifi_serv);
    wifi_service_register_setting_handle(wifi_serv, wifi_setting_handle, &reg_idx);
    wifi_service_set_sta_info(wifi_serv, &sta_cfg);
    wifi_service_connect(wifi_serv);
}

static void cli_setup_console()
{
    periph_console_cfg_t console_cfg = {
        .command_num = sizeof(cli_cmd) / sizeof(periph_console_cmd_t),
        .commands = cli_cmd,
        .buffer_size = 384,
        .task_stack = 6 * 1024,
    };
    esp_periph_handle_t console_handle = periph_console_init(&console_cfg);
    esp_periph_start(set, console_handle);
}

void console_module_init(void)
{
    esp_log_level_set("*", ESP_LOG_INFO);

    ESP_ERROR_CHECK(nvs_flash_init());
#if (ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 1, 0))
    ESP_ERROR_CHECK(esp_netif_init());
#else
    tcpip_adapter_init();
#endif
    esp_periph_config_t periph_cfg = DEFAULT_ESP_PERIPH_SET_CONFIG();
#if !CONFIG_FREERTOS_UNICORE
    periph_cfg.task_core = 1;
#endif
    set = esp_periph_set_init(&periph_cfg);

    cli_setup_ble();
    cli_setup_wifi();

    cli_setup_console();
}
