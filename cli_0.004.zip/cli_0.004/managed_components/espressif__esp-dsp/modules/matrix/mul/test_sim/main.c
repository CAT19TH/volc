
void test_mmult();

int main(void)
{
    printf("main starts!\n");
//    xt_iss_profile_enable();
    test_mmult();
//    xt_iss_profile_disable();

    printf("Test done\n");
}
